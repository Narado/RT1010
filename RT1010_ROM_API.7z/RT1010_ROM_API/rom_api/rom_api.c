#include "rom_api.h"
#include "debug_printf.h"
#include "string_convert.h"

static void get_bootloader_version_number(uint32_t argc, uint8_t** argv);
static uint8_t help_info_get_bootloader_version_number[] = "\r\nget_bootloader_version_number";

static void get_bootloader_copyright(uint32_t argc, uint8_t** argv);
static uint8_t help_info_get_bootloader_copyright[] = "\r\nget_bootloader_copyright";

static void run_bootloader(uint32_t argc, uint8_t** argv);
static uint8_t help_info_run_bootloader[] = "\r\nrun_bootloader <tag> <boot_mode> <serial_boot_interface> <image_index>"
                                            "\r\n<tag> must be 0xEB."
                                            "\r\n<boot_mode> 0 - Determined by BMODE in SMBR2 or other Fuse combination"
                                            "\r\n            1 - Serial downloader"
                                            "\r\n            2 - Determined by BMODE in SMBR2 or other Fuse combination"
                                            "\r\n            Others - Reserved"
                                            "\r\n<serial_boot_interface> 0 - Auto"
                                            "\r\n                        1 - USB"
                                            "\r\n                        2 - UART"
                                            "\r\n<image_index> 0 - Image 0"
                                            "\r\n              1 - Image 1"
                                            "\r\n              2 - Image 2"
                                            "\r\n              3 - Image 3";

const bl_function_t rom_api_functions[] = {
    {"get_bootloader_version_number", help_info_get_bootloader_version_number, get_bootloader_version_number},
    {"get_bootloader_copyright", help_info_get_bootloader_copyright, get_bootloader_copyright},
    {"run_bootloader", help_info_run_bootloader, run_bootloader},
    {NULL, NULL, NULL}
}; 

const bootloader_api_entry_t* rom_api = (const bootloader_api_entry_t*)BOOTLOADER_TREE_LOCATION;



static void get_bootloader_version_number(uint32_t argc, uint8_t** argv)
{
    if(argc != 1)
    {
        debug_printf("\r\nError! 0 arguments required!%s", help_info_get_bootloader_version_number);
        return;
    }
    
    uint32_t version = rom_api->version;
    uint32_t major = (version >> 16) & 0xff;
    uint32_t minor = (version >> 8) & 0xff;
    uint32_t bugfix = version & 0xff;
    //Call ROM API function and send reponse
    debug_printf("\r\nInject command '%s'...", "get_bootloader_version_number");
    debug_printf("\r\nResponse status = 0 (0x0) Success.");
    debug_printf("\r\nResponse word 1 = %d (%x).", rom_api->version, rom_api->version);
    debug_printf("\r\nCurrunt Version = %d.%d.%d", major, minor, bugfix);
    debug_printf("\r\n");
}

static void get_bootloader_copyright(uint32_t argc, uint8_t** argv)
{
    if(argc != 1)
    {
        debug_printf("\r\nError! 0 arguments required!%s", help_info_get_bootloader_copyright);
        return;
    }
    //Call ROM API function and send reponse
    debug_printf("\r\nInject command '%s'...", "get_bootloader_copyright");
    debug_printf("\r\nResponse status = 0 (0x0) Success.");
    debug_printf("\r\nResponse word 1 = %s.", rom_api->copyright);
    debug_printf("\r\nCurrent Copyright = '%s'", rom_api->copyright);
    debug_printf("\r\n");
}
static void run_bootloader(uint32_t argc, uint8_t** argv)
{
    uint32_t tag = 0;
    uint32_t boot_mode = 0;
    uint32_t serial_boot_interface = 0;
    uint32_t image_index = 0;
    uint8_t* tmp_arg = NULL;
    
    if(argc != 5)
    {
        debug_printf("\r\nError! 4 arguments required!%s", help_info_run_bootloader);
        return;
    }
    
    tmp_arg = argv[1];
    if(ascii_to_int(&tag, tmp_arg) == false)
    {
        debug_printf("\r\n<tag> value error! Must be 0xEB");
        return;
    }
    
    tmp_arg = argv[2];
    if(ascii_to_int(&boot_mode, tmp_arg) == false)
    {
        debug_printf("\r\n<boot_mode> value type error!");
        return;
    }
    
    tmp_arg = argv[3];
    if(ascii_to_int(&serial_boot_interface, tmp_arg) == false)
    {
        debug_printf("\r\n<serial_boot_interface> value type error!");
        return;
    }
    
    tmp_arg = argv[4];
    if(ascii_to_int(&image_index, tmp_arg) == false)
    {
        debug_printf("\r\n<image_index> value type error!");
        return;
    }
    
    run_bootloader_ctx_t ctx;
    ctx.B.tag = tag; // Must be 0xEB;
    ctx.B.bootMode = boot_mode;
    ctx.B.serialBootInterface = serial_boot_interface;
    ctx.B.imageIndex = image_index;   
    
    //Call ROM API function and send reponse
    debug_printf("\r\nInject command '%s'...", "run_bootloader");
    rom_api->runBootloader(&ctx);
    
    //Should never run to here if enter ROM serial downloader mode sucessfully.
    debug_printf("\r\nResponse status = 0 (0x0) StillInUserApplication.");
    debug_printf("\r\nResponse word 1 = 0 (0x0).");
    debug_printf("\r\n");
}