#ifndef _ROM_API_H_
#define _ROM_API_H_
#include <stdint.h>

//#define BOOTLOADER_TREE_LOCATION 0x0020db58
#define BOOTLOADER_TREE_LOCATION 0x0020dab0
typedef struct
{
    const uint32_t version;                                 //!< Bootloader version number
    const char *copyright;                                  //!< Bootloader Copyright
    void (*runBootloader)(void *arg);                       //!< Function to start the bootloader executing
    /*
    const hab_rvt_t *habDriver;                             //!< HAB API
    const flexspi_nor_driver_interface_t *flexSpiNorDriver; //!< FlexSPI NOR Flash API
    // Trimmed for RT1010
    // const nand_ecc_driver_interface_t *nandEccDriver;
    // const clock_driver_interface_t *clockDriver;
    const rtwdog_driver_interface_t *rtwdogDriver;
    const wdog_driver_interface_t *wdogDriver;
    const stdlib_driver_interface_t *stdlibDriver;
    */
} bootloader_api_entry_t;

typedef union
{
    struct
    {
        uint32_t imageIndex:4;
        uint32_t reserved:12;
        uint32_t serialBootInterface:4;
        uint32_t bootMode:4;
        uint32_t tag:8;
    }B;
    uint32_t U;
}run_bootloader_ctx_t;

typedef struct {
    uint8_t *func_name;
    uint8_t *func_usage;
    void (*func_execute) (uint32_t, uint8_t**);
} bl_function_t;

void run_bootloader_enter_serial_downloader_mode_uart(run_bootloader_ctx_t* arg);
#endif