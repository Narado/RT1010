#include "string_convert.h"

bool ascii_to_int(uint32_t *uint, uint8_t *str)
{
    bool is_hex = false;
    uint32_t ret = 0;
    if((str == 0) || (uint == 0))
    {
        return false;
    }
    if(*str == 0)
    {
        *uint = 0;
        return false;
    }
    
    if((*str == '0') && ((*(str+1) == 'x') || (*(str+1) == 'X')) )
    {
        is_hex = true;
        str += 2;
    }
    while(*str)
    {
        if(is_hex)
        {
            ret *= 16;
        }
        else
        {
            ret *= 10;
        }
        if((*str >= '0') && (*str <= '9'))
        {
            ret += *str - '0';
        }
        else if(is_hex && (*str >= 'a') && (*str <= 'f'))
        {
            ret += *str - 'a' + 10;
        }
        else if(is_hex && (*str >= 'A') && (*str <= 'F'))
        {
            ret += *str - 'A' + 10;
        }
        else
        {
            *uint = 0;
            return false;
        }
        str++;
    }
    *uint = ret;
    return true;
}