#ifndef _COMMAND_HANDLER_H_
#define _COMMAND_HANDLER_H_
#include <stdint.h>
#include "debug_printf.h"

void init_command_processing(void);
void recieve_command(uint8_t c);
//void handle_command(uint8_t* command);
#endif