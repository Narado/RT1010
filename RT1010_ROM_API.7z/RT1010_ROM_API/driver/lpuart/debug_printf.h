#ifndef _DEBUG_PRINTF_H_
#define _DEBUG_PRINTF_H_

#include <stdint.h>
#include "fsl_lpuart.h"
#define LPUART_DEBUG            LPUART4
#define LPUART_BAUDRATE         115200

void debug_printf(const char *format, ...);
void debug_scanf(uint8_t *value);

#endif