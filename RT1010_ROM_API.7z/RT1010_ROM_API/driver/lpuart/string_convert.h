#ifndef _STRING_CONVERT_H_
#define _STRING_CONVERT_H_

#include <stdint.h>
#include <stdbool.h>
bool ascii_to_int(uint32_t *uint, uint8_t *str);

#endif