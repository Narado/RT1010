#include "command_handler.h"
#include "rom_api.h"

/*! @brief input buffer size */
#define k_cmdBufferSize 100

/*! @brief input History depth */
#define k_cmdHistoryDepth 2

/*! @brief max input command args */
#define k_cmdMaxArgs 10
#define k_cmdArgLength  40

static uint8_t s_inputBuffer[k_cmdHistoryDepth][k_cmdBufferSize] = {0};
static uint32_t s_curBufIndex = 0;
static uint32_t s_curCmdIndex = 0;
extern const bl_function_t rom_api_functions[];


void print_function_usage()
{
    const bl_function_t *api = &rom_api_functions[0];
    debug_printf("\r\nFunction Usage:");
    while(api->func_usage)
    {
        debug_printf("%s", api->func_usage);
        api++;
    }
    debug_printf("\r\n>");
}

void init_command_processing(void)
{
    debug_printf("\r\n---------------------------------------------------------");
    debug_printf("\r\n|         Please input command:                         |");
    debug_printf("\r\n---------------------------------------------------------");
    print_function_usage();
    s_curBufIndex = 0;
    s_curCmdIndex = 0;
}

void handle_command(uint8_t* command)
{
   
    uint8_t temp[k_cmdBufferSize] ={0};
    uint8_t *string = temp;
    uint8_t* cmd =  command;
    
    uint8_t *argv[k_cmdMaxArgs];
    uint8_t i;
    uint32_t argc = 0;
    for(i = 0; i < k_cmdMaxArgs; i++)
    {
        argv[i] = NULL;
    }
    
    memcpy(temp, cmd, strlen((char*)cmd));
    while(*string && (argc < k_cmdMaxArgs))
    {
        while(*string == ' ')
        {
            string++;
        }
        if(*string == 0)
        {
            break;
        }
        argv[argc++] = string;
        while(*string && (*string != ' '))
        {
            string++;
        }
        if(*string == 0)
        {
            break;
        }
        *string++ = 0;
    }
//                        for(i = 0; i < k_cmdMaxArgs; i++)
//                        {
//                            if(argv[i] == NULL)
//                            {
//                                break;
//                            }
//                            else
//                            {
//                                debug_printf("\r\narg[%d] = %s", i, argv[i]);
//                            }
//                        }
    
    //Match the function name 
    uint8_t *p = (uint8_t*)(argv[0]);
    uint8_t *func_name = NULL;
    bool is_matched = false;
    if(p)
    {        
        const bl_function_t *api = &rom_api_functions[0];
        while(api->func_name != NULL)
        {
            func_name = api->func_name;
            p = (uint8_t*)(argv[0]);
            while((*func_name) && (*p) && (*func_name == *p))
            {
                func_name++;
                p++;
            }
            if((*func_name == 0) && (*p == 0))
            {
                is_matched = true;
                break;
            }               
            api++;
        }
        
        if(is_matched)
        {
            if(api->func_execute)
            {
                //debug_printf("\r\nFunction name matched!\r\n");
                //debug_printf("\r\nExecute %s function...\r\n", api->func_name);
                api->func_execute(argc, argv);
                //debug_printf("\r\n>");
            }
        }
        else
        {
            debug_printf("\r\nFunction name NOT matched!");
            print_function_usage();
        }
    }
}

void recieve_command(uint8_t c)
{
    uint8_t *buffer = s_inputBuffer[s_curBufIndex];
    if((c == '\n') || (c == '\r'))
    {
        handle_command(buffer); 
        s_curCmdIndex = 0;
        s_curBufIndex = (s_curBufIndex + 1) % k_cmdHistoryDepth;
        s_inputBuffer[s_curBufIndex][0] = 0;
        debug_printf("\r\n>");
    }
    else if((c == 0x08) || (c == 0x7f)) //Backspace and delete 
    {
        if(s_curCmdIndex > 0)
        {
            buffer[--s_curCmdIndex] = 0;
            debug_printf("\b \b");
        }
    }
    else
    {
        if(s_curCmdIndex < k_cmdBufferSize - 1)
        {
            debug_printf("%c", c);
            buffer[s_curCmdIndex++] = c;
            buffer[s_curCmdIndex] = 0;
        }
    }
}
