/*
 * The Clear BSD License
 * Copyright 2018 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted (subject to the limitations in the disclaimer below) provided
 * that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "fsl_common.h"
#include "fsl_clock.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
static uint32_t get_periph_clk(void)
{
    uint32_t periph_clk = 0;
    uint32_t frac = 0;
    uint32_t clock_source = 0;

    if (CCM->CBCDR & CCM_CBCDR_PERIPH_CLK_SEL_MASK) // Derive clock from periph_clk2_sel
    {
        clock_source = (CCM->CBCMR & CCM_CBCMR_PERIPH_CLK2_SEL_MASK) >> CCM_CBCMR_PERIPH_CLK2_SEL_SHIFT;
        if (clock_source == 0)
        {
            periph_clk = FREQ_480MHz;
        }
        else
        {
            periph_clk = FREQ_24MHz;
        }
    }
    else // Derive clock from pre_periph_clk_sel
    {
        clock_source = (CCM->CBCMR & CCM_CBCMR_PRE_PERIPH_CLK_SEL_MASK) >> CCM_CBCMR_PRE_PERIPH_CLK_SEL_SHIFT;

        switch(clock_source)
        {
        case 0: // SYS_PLL
            periph_clk = FREQ_528MHz;
            break;
        case 1: // PFD_480_PFD3
            frac = (CCM_ANALOG->PFD_480 & CCM_ANALOG_PFD_480_PFD3_FRAC_MASK) >> CCM_ANALOG_PFD_480_PFD3_FRAC_SHIFT;
            periph_clk = FREQ_480MHz / frac * 18; // Div-before-Mul: in case of overflow
            break;
        case 2: // PFD_528_PFD3
            frac = (CCM_ANALOG->PFD_528 & CCM_ANALOG_PFD_528_PFD3_FRAC_MASK) >> CCM_ANALOG_PFD_528_PFD3_FRAC_SHIFT;
            periph_clk = FREQ_528MHz / frac * 18; // Div-before-Mul: in case of overflow
            break;
        default: // ENET PLL / ARM_PODF
            if (CCM_ANALOG->PLL_ENET & CCM_ANALOG_PLL_ENET_BYPASS_MASK)
            {
                periph_clk = FREQ_24MHz;
            }
            else
            {
                periph_clk = FREQ_500MHz;
            }
            break;
        }
    }

    return periph_clk;
}

uint32_t get_core_clock(void)
{
    uint32_t periph_clk = get_periph_clk();
    uint32_t ahb_podf = 1 + ((CCM->CBCDR & CCM_CBCDR_AHB_PODF_MASK) >> CCM_CBCDR_AHB_PODF_SHIFT);
    uint32_t core_clock = periph_clk / ahb_podf;

    return core_clock;
}

uint32_t get_pll3_sw_clk(void)
{
    if(CCM_ANALOG->PLL_USB1 & CCM_ANALOG_PLL_ARM_BYPASS(1)) // PLL 480 bypassed
    {
        return FREQ_24MHz;
    }
    else // PLL 480 direct output
    {
        return FREQ_480MHz;
    }

}
