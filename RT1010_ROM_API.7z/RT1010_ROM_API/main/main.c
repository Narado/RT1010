#include <stdint.h>
#include <stdio.h>
#include "fsl_lpuart.h"
#include "debug_printf.h"
#include "command_handler.h"
#include "rom_api.h"


void delay(){
    for(int i=2000000; i>0; i--);
}


void lpuart_init(void)
{
#if defined(BL_TARGET_FPGA) && defined(BL_DEBUG_UART)
    CCM->CCGR1 |= CCM_CCGR5_CG12_MASK; //Enable LPUART4 clock gating
    
    CCM->CSCDR1 = CCM->CSCDR1 & ~(CCM_CSCDR1_UART_CLK_SEL_MASK);
    CCM->CSCDR1 = (CCM->CSCDR1 & ~(CCM_CSCDR1_UART_CLK_PODF_MASK)) | CCM_CSCDR1_UART_CLK_PODF(3);
    
    //LPUART4_TX, GPIO_SD_B1_00, ALT2
    IOMUXC->SW_MUX_CTL_PAD[kIOMUXC_SW_MUX_CTL_PAD_GPIO_06] = 0x03;
    IOMUXC->SELECT_INPUT[kIOMUXC_SW_MUX_CTL_PAD_GPIO_06] = 0x1;
    
    //LPUART4_RX, GPIO_SD_B1_01, ALT2
    IOMUXC->SW_MUX_CTL_PAD[kIOMUXC_SW_MUX_CTL_PAD_GPIO_05] = 0x03;
    IOMUXC->SELECT_INPUT[kIOMUXC_SW_MUX_CTL_PAD_GPIO_05] = 0x1;
    
    
    lpuart_config_t userConfig={0};
    LPUART_GetDefaultConfig(&userConfig);
    userConfig.baudRate_Bps = LPUART_BAUDRATE;
    userConfig.enableTx=true;
    LPUART_Init(LPUART_DEBUG, &userConfig, 6000000); // For debugging purposes
    LPUART_EnableTx(LPUART_DEBUG, true);
    LPUART_EnableRx(LPUART_DEBUG, true);
#endif
}
int main()
{  
    lpuart_init(); 
    debug_printf("\r\nWelcome to i.MX RT1010 ROM API testing world!");
    init_command_processing();
    uint8_t ch;
    while(1)
    {
        debug_scanf(&ch);
        recieve_command(ch);
    }
    return 0;
}
