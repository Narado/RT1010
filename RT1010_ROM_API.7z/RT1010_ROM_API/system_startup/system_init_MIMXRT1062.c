#include <stdint.h>
#include "fsl_device_registers.h"

void wdog32_disable(void)
{
    // Leave reset value of timout
    RTWDOG->TOVAL |= 0x80;
    // Disable WDOG and keep WDOG3_CS[UPDATE] to 1
    RTWDOG->CS = ((RTWDOG->CS) & ((uint32_t) ~(RTWDOG_CS_UPDATE_MASK | RTWDOG_CS_EN_MASK))) | RTWDOG_CS_UPDATE(1);
}

void SystemInit (void) 
{
#if ((__FPU_PRESENT == 1) && (__FPU_USED == 1))
    SCB->CPACR |= ((3UL << 10*2) | (3UL << 11*2));    /* set CP10, CP11 Full Access */
#endif /* ((__FPU_PRESENT == 1) && (__FPU_USED == 1)) */

/* Watchdog disable */
#if (DISABLE_WDOG)
    wdog32_disable();
#endif /* (DISABLE_WDOG) */

/* Enable instruction caches */
#if defined(__ICACHE_PRESENT) && __ICACHE_PRESENT
    SCB_EnableICache();
#endif
    
/* Enable data caches */    
#if defined(__DCACHE_PRESENT) && __DCACHE_PRESENT
    SCB_EnableDCache();
#endif

}